#include "adminwindow.h"
#include "ui_adminwindow.h"
#include <QInputDialog>
#include <QRegExp>
#include <QSqlQuery>

AdminWindow::AdminWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AdminWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Окно Администрирования Системы");

    setupModels();
    setupTableViews();
}

AdminWindow::~AdminWindow()
{
    delete ui;
}

void AdminWindow::setupModels()
{
    usersModel = new QSqlTableModel(this);
    usersModel->setTable("Users");
    QSqlQuery query;
    query.prepare("SELECT * FROM Users");
    if (query.exec()) {
        usersModel->setQuery("SELECT * FROM Users");
        ui->usersTableView->setModel(usersModel);
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
    }

    dronesModel = new QSqlTableModel(this);
    dronesModel->setTable("Drones");
    query.prepare("SELECT * FROM Drones");
    if (query.exec()) {
        dronesModel->setQuery("SELECT * FROM Drones");
        ui->dronesTableView->setModel(dronesModel);
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
    }

    sectorsModel = new QSqlTableModel(this);
    sectorsModel->setTable("PatrolSectors");
    query.prepare("SELECT * FROM PatrolSectors");
    if (query.exec()) {
        sectorsModel->setQuery("SELECT * FROM PatrolSectors");
        ui->sectorsTableView->setModel(sectorsModel);
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
    }
    sensorsModel = new QSqlTableModel(this);
    sensorsModel->setTable("Sensors");
    query.prepare("SELECT * FROM Sensors");
    if (query.exec()) {
        sensorsModel->setQuery("SELECT * FROM Sensors");
        ui->sensorsTableView->setModel(sensorsModel);
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
    }
}

void AdminWindow::setupTableViews()
{
    ui->usersTableView->setModel(usersModel);
    ui->dronesTableView->setModel(dronesModel);
    ui->sectorsTableView->setModel(sectorsModel);
    ui->sensorsTableView->setModel(sensorsModel);
}

bool AdminWindow::validateInput(const QString &input)
{
    if (input.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Поле не должно быть пустым.");
        return false;
    }
    QRegExp re("[A-Za-zА-Яёа-я0-9]+");
    if (!re.exactMatch(input)) {
        QMessageBox::warning(this, "Ошибка", "Поле должно содержать только буквы и цифры.");
        return false;
    }
    return true;
}

void AdminWindow::on_addButton_clicked()
{
    QString tableName = ui->tabWidget->currentWidget()->objectName();

    if (tableName == "tabUsers") {
        // Добавление пользователя
        QString username = QInputDialog::getText(this, "Добавить пользователя", "Имя пользователя:");
        QString password = QInputDialog::getText(this, "Добавить пользователя", "Пароль:", QLineEdit::Password);
        QString role = QInputDialog::getText(this, "Добавить пользователя", "Роль:");

        if (validateInput(username) && validateInput(password) && validateInput(role)) {
            if (!DatabaseManager::instance().addUser(username, password, role)) {
                QMessageBox::warning(this, "Ошибка", "Не удалось добавить пользователя.");
            } else {
                QSqlQuery query;
                query.prepare("SELECT * FROM Users");
                if (query.exec()) {
                    usersModel->setQuery("SELECT * FROM Users");
                    ui->usersTableView->setModel(usersModel);
                } else {
                    qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
                }
            }
        }

    } else if (tableName == "tabDrones") {
        // Добавление дрона
        QString name = QInputDialog::getText(this, "Добавить дрон", "Имя:");
        QString type = QInputDialog::getText(this, "Добавить дрон", "Тип:");
        QString userid = QInputDialog::getText(this, "Добавить дрон", "Оператор:");

        if (validateInput(name) && validateInput(type)&& validateInput(userid)) {
            if (!DatabaseManager::instance().addDrone(name, type, userid)) {
                QMessageBox::warning(this, "Ошибка", "Не удалось добавить пользователя.");
            } else {
                QSqlQuery query;
                query.prepare("SELECT * FROM drones");
                if (query.exec()) {
                    dronesModel->setQuery("SELECT * FROM drones");
                    ui->dronesTableView->setModel(dronesModel);
                } else {
                    qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
                }
            }
        }
    } else if (tableName == "tabSectors") {
        // Добавление сектора патрулирования
        QString name = QInputDialog::getText(this, "Добавить сектор патрулирования", "Имя:");
        QString description = QInputDialog::getText(this, "Добавить сектор патрулирования", "Описание:");

        if (validateInput(name) && validateInput(description)) {
            if (!DatabaseManager::instance().addSectors(name, description)) {
                QMessageBox::warning(this, "Ошибка", "Не удалось добавить пользователя.");
            } else {
                QSqlQuery query;
                query.prepare("SELECT * FROM patrolsectors");
                if (query.exec()) {
                    sectorsModel->setQuery("SELECT * FROM patrolsectors");
                    ui->sectorsTableView->setModel(sectorsModel);
                } else {
                    qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
                }
            }
        }
    } else if (tableName == "tabSensors") {
        // Добавление сенсора
        QString type = QInputDialog::getText(this, "Добавить сенсор", "Тип:");
        QString description = QInputDialog::getText(this, "Добавить сенсор", "Описание:");

        if (validateInput(type) && validateInput(description)) {
            if (!DatabaseManager::instance().addSensors(type, description)) {
                QMessageBox::warning(this, "Ошибка", "Не удалось добавить пользователя.");
            } else {
                QSqlQuery query;
                query.prepare("SELECT * FROM sensors");
                if (query.exec()) {
                    sensorsModel->setQuery("SELECT * FROM sensors");
                    ui->sensorsTableView->setModel(sensorsModel);
                } else {
                    qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
                }
            }
        }
    }
}

void AdminWindow::on_editButton_clicked()
{
    QString tableName = ui->tabWidget->currentWidget()->objectName();
    QModelIndex currentIndex;
    QSqlTableModel *currentModel;

    if (tableName == "tabUsers") {
        currentIndex = ui->usersTableView->currentIndex();
        currentModel = usersModel;
    } else if (tableName == "tabDrones") {
        currentIndex = ui->dronesTableView->currentIndex();
        currentModel = dronesModel;
    } else if (tableName == "tabSectors") {
        currentIndex = ui->sectorsTableView->currentIndex();
        currentModel = sectorsModel;
    } else if (tableName == "tabSensors") {
        currentIndex = ui->sensorsTableView->currentIndex();
        currentModel = sensorsModel;
    }

    if (!currentIndex.isValid()) {
        QMessageBox::warning(this, "Ошибка", "Выберите запись для редактирования.");
        return;
    }

    if (tableName == "tabUsers") {
        QString username = QInputDialog::getText(this, "Изменить пользователя", "Имя пользователя:");
        QString password = QInputDialog::getText(this, "Изменить пользователя", "Пароль:", QLineEdit::Password);
        QString role = QInputDialog::getText(this, "Изменить пользователя", "Роль:");

        if (validateInput(username) && validateInput(password) && validateInput(role)) {
            QSqlRecord record = currentModel->record(currentIndex.row());
            record.setValue("Username", username);
            record.setValue("Password", QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Md5).toHex());
            record.setValue("Role", role);

            if (!currentModel->setRecord(currentIndex.row(), record)) {
                //QMessageBox::warning(this, "Ошибка", "Не удалось изменить пользователя.");
            } else {
                QSqlQuery query;
                query.prepare("SELECT * FROM Users");
                if (query.exec()) {
                    usersModel->setQuery("SELECT * FROM Users");
                    ui->usersTableView->setModel(usersModel);
                } else {
                    qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
                }
            }
        }
    } else if (tableName == "tabDrones") {
        QString name = QInputDialog::getText(this, "Изменить дрон", "Имя:");
        QString type = QInputDialog::getText(this, "Изменить дрон", "Тип:");

        if (validateInput(name) && validateInput(type)) {
            QSqlRecord record = currentModel->record(currentIndex.row());
            record.setValue("Name", name);
            record.setValue("Type", type);

            if (!currentModel->setRecord(currentIndex.row(), record)) {
                //QMessageBox::warning(this, "Ошибка", "Не удалось изменить дрон.");
            } else {
                QSqlQuery query;
                query.prepare("SELECT * FROM Drones");
                if (query.exec()) {
                    dronesModel->setQuery("SELECT * FROM Drones");
                    ui->dronesTableView->setModel(dronesModel);
                } else {
                    qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
                }
            }
        }
    } else if (tableName == "tabSectors") {
        QString name = QInputDialog::getText(this, "Изменить сектор патрулирования", "Имя:");
        QString description = QInputDialog::getText(this, "Изменить сектор патрулирования", "Описание:");

        if (validateInput(name) && validateInput(description)) {
            QSqlRecord record = currentModel->record(currentIndex.row());
            record.setValue("Name", name);
            record.setValue("Description", description);

            if (!currentModel->setRecord(currentIndex.row(), record)) {
                //QMessageBox::warning(this, "Ошибка", "Не удалось изменить сектор патрулирования.");
            } else {
                QSqlQuery query;
                query.prepare("SELECT * FROM PatrolSectors");
                if (query.exec()) {
                    sectorsModel->setQuery("SELECT * FROM PatrolSectors");
                    ui->sectorsTableView->setModel(sectorsModel);
                } else {
                    qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
                }
            }
        }
    } else if (tableName == "tabSensors") {
        QString type = QInputDialog::getText(this, "Изменить сенсор", "Тип:");
        QString description = QInputDialog::getText(this, "Изменить сенсор", "Описание:");

        if (validateInput(type) && validateInput(description)) {
            QSqlRecord record = currentModel->record(currentIndex.row());
            record.setValue("Type", type);
            record.setValue("Description", description);

            if (!currentModel->setRecord(currentIndex.row(), record)) {
                //QMessageBox::warning(this, "Ошибка", "Не удалось изменить сенсор.");
            } else {
                QSqlQuery query;
                query.prepare("SELECT * FROM Sensors");
                if (query.exec()) {
                    sensorsModel->setQuery("SELECT * FROM Sensors");
                    ui->sensorsTableView->setModel(sensorsModel);
                } else {
                    qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
                }
            }
        }
    }
}


void AdminWindow::on_deleteButton_clicked()
{
    QString tableName = ui->tabWidget->currentWidget()->objectName();
    QModelIndex currentIndex;
    QString idColumn;
    QString table;
    QSqlTableModel *currentModel;

    if (tableName == "tabUsers") {
        currentIndex = ui->usersTableView->currentIndex();
        currentModel = usersModel;
        idColumn = "id";
        table = "Users";
    } else if (tableName == "tabDrones") {
        currentIndex = ui->dronesTableView->currentIndex();
        currentModel = dronesModel;
        idColumn = "ID";
        table = "Drones";
    } else if (tableName == "tabSectors") {
        currentIndex = ui->sectorsTableView->currentIndex();
        currentModel = sectorsModel;
        idColumn = "ID";
        table = "PatrolSectors";
    } else if (tableName == "tabSensors") {
        currentIndex = ui->sensorsTableView->currentIndex();
        currentModel = sensorsModel;
        idColumn = "ID";
        table = "Sensors";
    }

    if (!currentIndex.isValid()) {
        QMessageBox::warning(this, "Ошибка", "Выберите запись для удаления.");
        return;
    }

    if (QMessageBox::question(this, "Удалить запись", "Вы уверены, что хотите удалить эту запись?") == QMessageBox::Yes) {
        int id = currentModel->data(currentModel->index(currentIndex.row(), 0)).toInt();

        // Проверка значения id
        qDebug() << "ID для удаления:" << id;

        QSqlQuery query;
        QString queryString = QString("DELETE FROM %1 WHERE %2 = %3").arg(table, idColumn, QString::number(id));

        // Проверка строки запроса
        qDebug() << "Запрос на удаление:" << queryString;

        if (!query.exec(queryString)) {
            QMessageBox::warning(this, "Ошибка", "Не удалось удалить запись: " + query.lastError().text());

            // Проверка ошибки SQL-запроса
            qDebug() << "Ошибка SQL-запроса:" << query.lastError().text();
        } else {
            // Обновление модели после удаления
            if (tableName == "tabUsers") {
                usersModel->setQuery("SELECT * FROM Users");
                ui->usersTableView->setModel(usersModel);
            } else if (tableName == "tabDrones") {
                dronesModel->setQuery("SELECT * FROM Drones");
                ui->dronesTableView->setModel(dronesModel);
            } else if (tableName == "tabSectors") {
                sectorsModel->setQuery("SELECT * FROM PatrolSectors");
                ui->sectorsTableView->setModel(sectorsModel);
            } else if (tableName == "tabSensors") {
                sensorsModel->setQuery("SELECT * FROM Sensors");
                ui->sensorsTableView->setModel(sensorsModel);
            }

            QMessageBox::information(this, "Успех", "Запись успешно удалена.");
        }
    }
}



void AdminWindow::on_refreshButton_clicked()
{
    QSqlQuery query;

    query.prepare("SELECT * FROM Users");
    if (query.exec()) {
        usersModel->setQuery("SELECT * FROM Users");
        ui->usersTableView->setModel(usersModel);
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
    }

    query.prepare("SELECT * FROM Drones");
    if (query.exec()) {
        dronesModel->setQuery("SELECT * FROM Drones");
        ui->dronesTableView->setModel(dronesModel);
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
    }

    query.prepare("SELECT * FROM PatrolSectors");
    if (query.exec()) {
        sectorsModel->setQuery("SELECT * FROM PatrolSectors");
        ui->sectorsTableView->setModel(sectorsModel);
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
    }

    query.prepare("SELECT * FROM Sensors");
    if (query.exec()) {
        sensorsModel->setQuery("SELECT * FROM Sensors");
        ui->sensorsTableView->setModel(sensorsModel);
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
    }
}


void AdminWindow::on_logoutButton_clicked()
{
    this->close();
    Login *loginWindow = new Login();
    loginWindow->show();
}

