#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVector>

class AdminWindow; // Предварительное объявление класса AdminWindow

class DatabaseManager {
public:
    static DatabaseManager& instance(); // Метод для получения единственного экземпляра DatabaseManager

    bool openDatabase();
    void closeDatabase();
    QString authenticateUser(const QString &username, const QString &password);
    bool createTables();
    bool addUser(const QString &username, const QString &password, const QString &role);
    bool addDrone(const QString &name, const QString &type, const QString &userid);
    bool addSectors(const QString &name, const QString &description);
    bool addSensors(const QString &type, const QString &description);
    QVector<QVector<QString>> getPatrolSectors();
    QVector<QVector<QString>> getDroneSensors();
    QVector<QVector<QString>> getDronePatrols();
    QVector<QVector<QString>> getDroneEvents();
    QVector<QVector<QString>> getDroneData();
    QVector<QVector<QString>> getUserData();
     QVector<QVector<QString>> getSectorData();
    QVector<QVector<QString>> getDeviceData();
    QVector<QVector<QString>> getEventData();



private:
    DatabaseManager();
    ~DatabaseManager(); // Деструктор для закрытия и удаления соединения

    DatabaseManager(const DatabaseManager&) = delete;
    DatabaseManager& operator=(const DatabaseManager&) = delete;

    QSqlDatabase m_database;

    // Дружественные классы
    friend class Login;
    friend class UserWindow;
    friend class AdminWindow;
    friend class InformationHub;
    friend class AnalystWindow;

};

#endif // DATABASEMANAGER_H
