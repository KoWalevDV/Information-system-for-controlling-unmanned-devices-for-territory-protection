#include "databasemanager.h"
#include <QCryptographicHash>

DatabaseManager::DatabaseManager() {
    // Инициализация базы данных и других членов класса
}

DatabaseManager::~DatabaseManager() {
    closeDatabase();
    QSqlDatabase::removeDatabase(QSqlDatabase::defaultConnection);
}

DatabaseManager& DatabaseManager::instance() {
    static DatabaseManager instance;
    return instance;
}

bool DatabaseManager::openDatabase() {
    if (!QSqlDatabase::contains(QSqlDatabase::defaultConnection)) {
        m_database = QSqlDatabase::addDatabase("QPSQL");
    } else {
        m_database = QSqlDatabase::database(QSqlDatabase::defaultConnection);
    }
    m_database.setHostName("localhost");
    m_database.setPort(5432);
    m_database.setDatabaseName("ISAD");
    m_database.setUserName("postgres");
    m_database.setPassword("root");

    return m_database.open();
}

void DatabaseManager::closeDatabase() {
    if (m_database.isOpen()) {
        m_database.close();
    }
}

QString DatabaseManager::authenticateUser(const QString &username, const QString &password) {
    if (!m_database.isOpen() && !openDatabase()) {
        return QString();
    }

    QSqlQuery query;
    query.prepare("SELECT Role FROM Users WHERE Username = :username AND Password = :password");
    query.bindValue(":username", username);

    // Хэширование пароля перед выполнением запроса
    QByteArray hashedPassword = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Md5);
    query.bindValue(":password", QString(hashedPassword.toHex()));

    if (query.exec() && query.next()) {
        return query.value(0).toString();
    } else {
        return QString();
    }
}

bool DatabaseManager::createTables() {
    if (!m_database.isOpen() && !openDatabase()) {
        return false;
    }

    QSqlQuery query(m_database);
    bool success = true;

    // Создание таблицы пользователей
    success = query.exec("CREATE TABLE IF NOT EXISTS Users ("
                         "ID SERIAL PRIMARY KEY,"
                         "Username VARCHAR(255) NOT NULL UNIQUE,"
                         "Password VARCHAR(255) NOT NULL,"
                         "Role VARCHAR(50)"
                         ");");
    if (!success) {
        return false;
    }

    // Добавление главного администратора
    success = addUser("KovalevD", "18062003", "Администратор");
    if (!success) {
        return false;
    }

    // Создание таблицы беспилотных устройств
    success = query.exec("CREATE TABLE IF NOT EXISTS Drones ("
                         "ID SERIAL PRIMARY KEY,"
                         "Name VARCHAR(255) NOT NULL,"
                         "Type VARCHAR(255) NOT NULL,"
                         "UserID INTEGER REFERENCES Users(ID)"
                         ");");
    if (!success) {
        return false;
    }

    // Создание таблицы секторов патрулирования
    success = query.exec("CREATE TABLE IF NOT EXISTS PatrolSectors ("
                         "ID SERIAL PRIMARY KEY,"
                         "Name VARCHAR(255) NOT NULL,"
                         "Description TEXT"
                         ");");
    if (!success) {
        return false;
    }

    // Создание таблицы связи между дронами и секторами патрулирования
    success = query.exec("CREATE TABLE IF NOT EXISTS DronePatrols ("
                         "DroneID INTEGER REFERENCES Drones(ID),"
                         "SectorID INTEGER REFERENCES PatrolSectors(ID),"
                         "PRIMARY KEY (DroneID, SectorID),"
                         "TakeoffTimestamp TIMESTAMP,"
                         "TimeEvent TIMESTAMP"
                         ");");
    if (!success) {
        return false;
    }

    // Создание таблицы сенсоров
    success = query.exec("CREATE TABLE IF NOT EXISTS Sensors ("
                         "ID SERIAL PRIMARY KEY,"
                         "Type VARCHAR(255) NOT NULL,"
                         "Description TEXT"
                         ");");
    if (!success) {
        return false;
    }

    // Создание таблицы связи между дронами и сенсорами
    success = query.exec("CREATE TABLE IF NOT EXISTS DroneSensors ("
                         "DroneID INTEGER REFERENCES Drones(ID),"
                         "SensorID INTEGER REFERENCES Sensors(ID),"
                         "PRIMARY KEY (DroneID, SensorID)"
                         ");");
    if (!success) {
        return false;
    }

    // Создание таблицы событий
    success = query.exec("CREATE TABLE IF NOT EXISTS Events ("
                         "ID SERIAL PRIMARY KEY,"
                         "EventType VARCHAR(255) NOT NULL,"
                         "EventDescription TEXT"
                         ");");
    if (!success) {
        return false;
    }

    // Создание таблицы связи между событиями и дронами
    success = query.exec("CREATE TABLE IF NOT EXISTS DroneEvent ("
                         "EventID INTEGER REFERENCES Events(ID),"
                         "DroneID INTEGER REFERENCES Drones(ID),"
                         "PRIMARY KEY (EventID, DroneID),"
                         "TimeEvent TIMESTAMP"
                         ");");
    if (!success) {
        return false;
    }

    return true;
}

bool DatabaseManager::addUser(const QString &username, const QString &password, const QString &role) {
    if (!m_database.isOpen() && !openDatabase()) {
        return false;
    }

    QSqlQuery query(m_database);
    query.prepare("INSERT INTO Users (Username, Password, Role) VALUES (:username, :password, :role)");

    // Хэширование пароля перед добавлением в базу данных
    QByteArray hashedPassword = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Md5);

    query.bindValue(":username", username);
    query.bindValue(":password", QString(hashedPassword.toHex()));
    query.bindValue(":role", role);

    return query.exec();
}

bool DatabaseManager::addDrone(const QString &name, const QString &type, const QString &userid) {
    if (!m_database.isOpen() && !openDatabase()) {
        return false;
    }

    QSqlQuery query(m_database);
    query.prepare("INSERT INTO Drones (name, type, userid) VALUES (:name, :type, :userid)");

    query.bindValue(":name", name);
    query.bindValue(":type", type);
    query.bindValue(":userid", userid);

    return query.exec();
}

bool DatabaseManager::addSectors(const QString &name, const QString &description) {
    if (!m_database.isOpen() && !openDatabase()) {
        return false;
    }

    QSqlQuery query(m_database);
    query.prepare("INSERT INTO patrolsectors (name, description ) VALUES (:name, :description)");

    query.bindValue(":name", name);
    query.bindValue(":description", description);

    return query.exec();
}

bool DatabaseManager::addSensors(const QString &type, const QString &description) {
    if (!m_database.isOpen() && !openDatabase()) {
        return false;
    }

    QSqlQuery query(m_database);
    query.prepare("INSERT INTO Sensors (type, description ) VALUES (:type, :description)");

    query.bindValue(":type", type);
    query.bindValue(":description", description);

    return query.exec();
}
QVector<QVector<QString>> DatabaseManager::getPatrolSectors()
{
    QVector<QVector<QString>> sectorsData;

    if (!m_database.isOpen() && !openDatabase()) {
        return sectorsData;
    }

    QSqlQuery query;
    if (!query.exec("SELECT * FROM PatrolSectors")) {
        return sectorsData;
    }

    while (query.next()) {
        QVector<QString> sector;
        sector.append(query.value(0).toString()); // ID
        sector.append(query.value(1).toString()); // Name
        sector.append(query.value(2).toString()); // Description
        sectorsData.append(sector);
    }

    return sectorsData;
}

QVector<QVector<QString>> DatabaseManager::getDroneSensors()
{
    QVector<QVector<QString>> sensorsData;

    if (!m_database.isOpen() && !openDatabase()) {
        return sensorsData;
    }

    QSqlQuery query;
    if (!query.exec("SELECT * FROM Sensors")) {
        return sensorsData;
    }

    while (query.next()) {
        QVector<QString> sensor;
        sensor.append(query.value(0).toString()); // ID
        sensor.append(query.value(1).toString()); // Type
        sensor.append(query.value(2).toString()); // Description
        sensorsData.append(sensor);
    }

    return sensorsData;
}

QVector<QVector<QString>> DatabaseManager::getDronePatrols()
{
    QVector<QVector<QString>> patrolsData;

    if (!m_database.isOpen() && !openDatabase()) {
        return patrolsData;
    }

    QSqlQuery query;
    if (!query.exec("SELECT * FROM DronePatrols")) {
        return patrolsData;
    }

    while (query.next()) {
        QVector<QString> patrol;
        patrol.append(query.value(0).toString()); // DroneID
        patrol.append(query.value(1).toString()); // SectorID
        patrol.append(query.value(2).toString()); // TakeoffTimestamp
        patrol.append(query.value(3).toString()); // TimeEvent
        patrolsData.append(patrol);
    }

    return patrolsData;
}

QVector<QVector<QString>> DatabaseManager::getDroneEvents()
{
    QVector<QVector<QString>> eventsData;

    if (!m_database.isOpen() && !openDatabase()) {
        return eventsData;
    }

    QSqlQuery query;
    if (!query.exec("SELECT * FROM DroneEvent")) {
        return eventsData;
    }

    while (query.next()) {
        QVector<QString> event;
        event.append(query.value(0).toString()); // EventID
        event.append(query.value(1).toString()); // DroneID
        event.append(query.value(2).toString()); // TimeEvent
        eventsData.append(event);
    }

    return eventsData;
}

QVector<QVector<QString>> DatabaseManager::getDroneData() {
    QVector<QVector<QString>> droneData;

    if (!m_database.isOpen() && !openDatabase()) {
        return droneData;
    }

    QSqlQuery query;
    if (!query.exec("SELECT ID, Name, Type,Userid FROM Drones")) {
        qDebug() << "Failed to fetch drone data:" << query.lastError().text();
        return droneData;
    }

    while (query.next()) {
        QVector<QString> droneRow;
        droneRow.push_back(query.value(0).toString()); // ID
        droneRow.push_back(query.value(1).toString()); // Name
        droneRow.push_back(query.value(2).toString());// Type
        droneRow.push_back(query.value(3).toString());//Userid
        droneData.push_back(droneRow);
    }

    qDebug() << "Drone data fetched successfully:" << droneData;
    return droneData;
}


QVector<QVector<QString>> DatabaseManager::getUserData() {
    QVector<QVector<QString>> userData;

    if (!m_database.isOpen() && !openDatabase()) {
        return userData;
    }

    QSqlQuery query;
    if (!query.exec("SELECT ID, Username, Role FROM Users")) {
        qDebug() << "Failed to fetch user data:" << query.lastError().text();
        return userData;
    }

    while (query.next()) {
        QVector<QString> userRow;
        userRow.push_back(query.value(0).toString()); // ID
        userRow.push_back(query.value(1).toString()); // Username
        userRow.push_back(query.value(2).toString()); // Role
        userData.push_back(userRow);
    }

    return userData;
}


QVector<QVector<QString>> DatabaseManager::getSectorData() {
    QVector<QVector<QString>> sectorData;

    if (!m_database.isOpen() && !openDatabase()) {
        return sectorData;
    }

    QSqlQuery query;
    if (!query.exec("SELECT ID, Name, Description FROM PatrolSectors")) {
        qDebug() << "Failed to fetch sector data:" << query.lastError().text();
        return sectorData;
    }

    while (query.next()) {
        QVector<QString> sectorRow;
        sectorRow.push_back(query.value(0).toString()); // ID
        sectorRow.push_back(query.value(1).toString()); // Name
        sectorRow.push_back(query.value(2).toString()); // Description
        sectorData.push_back(sectorRow);
    }

    return sectorData;
}

QVector<QVector<QString>> DatabaseManager::getDeviceData() {
    QVector<QVector<QString>> deviceData;

    if (!m_database.isOpen() && !openDatabase()) {
        return deviceData;
    }

    QSqlQuery query;
    if (!query.exec("SELECT ID, Type, Description FROM Sensors")) {
        qDebug() << "Failed to fetch device data:" << query.lastError().text();
        return deviceData;
    }

    while (query.next()) {
        QVector<QString> deviceRow;
        deviceRow.push_back(query.value(0).toString()); // ID
        deviceRow.push_back(query.value(1).toString()); // Type
        deviceRow.push_back(query.value(2).toString()); // Description
        deviceData.push_back(deviceRow);
    }

    return deviceData;
}

QVector<QVector<QString>> DatabaseManager::getEventData() {
    QVector<QVector<QString>> eventData;

    if (!m_database.isOpen() && !openDatabase()) {
        return eventData;
    }

    QSqlQuery query;
    if (!query.exec("SELECT ID, eventtype, eventdescription FROM events")) {
        qDebug() << "Failed to fetch device data:" << query.lastError().text();
        return eventData;
    }

    while (query.next()) {
        QVector<QString> eventRow;
        eventRow.push_back(query.value(0).toString()); // ID
        eventRow.push_back(query.value(1).toString()); // Type
        eventRow.push_back(query.value(2).toString()); // Description
       eventData.push_back(eventRow);
    }

    return eventData;
}
