#ifndef USERWINDOW_H
#define USERWINDOW_H

#include <QWidget>
#include <QComboBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QSqlQuery>
#include <QDateTime>
#include "databasemanager.h"
#include "informationhub.h"
#include "informationhub.h" // Включим заголовочный файл InformationHub

class UserWindow : public QWidget
{
    Q_OBJECT

public:
    explicit UserWindow(QWidget *parent = nullptr);
    ~UserWindow() = default;

private slots:
    void confirmData();
    void changeMode();
    void endSession();
    void openInformationHub();

private:
    void populateSectors();
    void populateDrones();
    void populateEventTypes();

    QComboBox *sectorComboBox;
    QComboBox *droneComboBox;
    QComboBox *eventTypeComboBox;
    QPushButton *confirmButton;
    QPushButton *changeModeButton;
    QPushButton *endSessionButton;

    InformationHub *informationHub;
};

#endif // USERWINDOW_H
