#include "analystwindow.h"
#include "ui_analystwindow.h"

AnalystWindow::AnalystWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AnalystWindow)
{
    ui->setupUi(this);
    setupConnections();
    loadData();
}

AnalystWindow::~AnalystWindow()
{
    delete ui;
}

void AnalystWindow::setupConnections()
{
    connect(ui->refreshButton, &QPushButton::clicked, this, &AnalystWindow::loadData);
    connect(ui->exportButton, &QPushButton::clicked, this, &AnalystWindow::exportReport);
}

void AnalystWindow::loadData()
{
    DatabaseManager &dbManager = DatabaseManager::instance();

    auto usersData = dbManager.getUserData();
    auto dronesData = dbManager.getDroneData();
    auto sectorsData = dbManager.getSectorData();
    auto sensorsData = dbManager.getDeviceData();
    auto dronePatrolsData = dbManager.getDronePatrols();
    auto droneEventsData = dbManager.getDroneEvents();

    populateTable(ui->usersTable, usersData);
    populateTable(ui->dronesTable, dronesData);
    populateTable(ui->sectorsTable, sectorsData);
    populateTable(ui->sensorsTable, sensorsData);
    populateTable(ui->dronePatrolsTable, dronePatrolsData);
    populateTable(ui->droneEventsTable, droneEventsData);
}

void AnalystWindow::populateTable(QTableWidget *table, const QVector<QVector<QString>> &data)
{
    table->setRowCount(data.size());
    if (data.isEmpty())
        return;

    table->setColumnCount(data[0].size());
    for (int row = 0; row < data.size(); ++row) {
        for (int col = 0; col < data[row].size(); ++col) {
            table->setItem(row, col, new QTableWidgetItem(data[row][col]));
        }
    }
}

void AnalystWindow::exportReport()
{
    QString fileName = QFileDialog::getSaveFileName(this, "Save Report", "", "Text Files (*.txt)");
    if (fileName.isEmpty())
        return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open file for writing.");
        return;
    }

    QTextStream out(&file);
    out << generateReport();

    file.close();
    QMessageBox::information(this, "Success", "Report saved successfully.");
}

QString AnalystWindow::generateReport()
{
    DatabaseManager &dbManager = DatabaseManager::instance();
    QString report;

    auto appendSection = [&report](const QString &title, const QVector<QVector<QString>> &data) {
        report.append(title + "\n");
        for (const auto &row : data) {
            report.append(row.join(", ") + "\n");
        }
        report.append("\n");
    };

    appendSection("Users:", dbManager.getUserData());
    appendSection("Drones:", dbManager.getDroneData());
    appendSection("Sectors:", dbManager.getSectorData());
    appendSection("Sensors:", dbManager.getDeviceData());
    appendSection("Drone Patrols:", dbManager.getDronePatrols());
    appendSection("Drone Events:", dbManager.getDroneEvents());

    return report;
}
