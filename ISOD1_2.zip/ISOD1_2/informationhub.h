#ifndef INFORMATIONHUB_H
#define INFORMATIONHUB_H

#include <QWidget>
#include <QTableWidget>
#include "databasemanager.h"
#include "QVBoxLayout"

class InformationHub : public QWidget
{
    Q_OBJECT
public:
    explicit InformationHub(QWidget *parent = nullptr);

private:
    QTableWidget *sectorTableWidget;
    QTableWidget *droneTableWidget;
    QTableWidget *eventsTableWidget;
    QTableWidget *eventTableWidget;

    DatabaseManager& databaseManager;

    void setupUI();
    void populatePatrolSectors();
    void populateDroneSensors();
    void populateDronePatrols();
    void populateDroneEvents();
};

#endif // INFORMATIONHUB_H
