#include "operatorwindow.h"

OperatorWindow::OperatorWindow(QWidget *parent) : QWidget(parent)
{
    setupUI();
    setupCamera();
    printVideoDevicesInfo();
}

void OperatorWindow::setupUI()
{
    QVBoxLayout *layout = new QVBoxLayout(this);

    mapLabel = new QLabel(this);
    // Установка изображения карты (путь к файлу или загрузка из ресурсов)
    QImage mapImage("C:/Users/DANYA/Desktop/drons/ISOD/ObjectPlane.jpg");
    mapLabel->setPixmap(QPixmap::fromImage(mapImage));
    mapLabel->setScaledContents(true); // Установка масштабирования изображения
    mapLabel->setMaximumSize(400, 200); // Установка максимального размера метки
    layout->addWidget(mapLabel);

    videoWidget = new QVideoWidget(this);
    layout->addWidget(videoWidget);

    setLayout(layout);
}


void OperatorWindow::setupCamera()
{
    // Получение списка доступных видеоустройств и их характеристик
    const QList<QCameraDevice> videoDevices = QMediaDevices::videoInputs();
    if (!videoDevices.isEmpty()) {
        // Используем первое доступное устройство
        const QCameraDevice &device = videoDevices.first();
        camera = new QCamera(device);
        camera->start();

        mediaCaptureSession = new QMediaCaptureSession(this);
        mediaCaptureSession->setCamera(camera);
        mediaCaptureSession->setVideoOutput(videoWidget);
    } else {
        // Если устройства не найдены, выдаем сообщение об ошибке
        QLabel *errorLabel = new QLabel("No video devices found", this);
        QVBoxLayout *layout = new QVBoxLayout(this);
        layout->addWidget(errorLabel);
        setLayout(layout);
    }
}

void OperatorWindow::printVideoDevicesInfo()
{
    QTextStream out(stdout);
    const QList<QCameraDevice> videoDevices = QMediaDevices::videoInputs();
    for (const QCameraDevice &device : videoDevices) {
        out << "ID: " << device.id() << Qt::endl;
        out << "Description: " << device.description() << Qt::endl;
        out << "Is default: " << (device.isDefault() ? "Yes" : "No") << Qt::endl;
    }
}
