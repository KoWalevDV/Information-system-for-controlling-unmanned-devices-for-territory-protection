#ifndef ANALYSTWINDOW_H
#define ANALYSTWINDOW_H

#include <QMainWindow>
#include <QTableWidget>
#include "databasemanager.h"
#include <QFileDialog>
#include <QMessageBox>

namespace Ui {
class AnalystWindow;
}

class AnalystWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AnalystWindow(QWidget *parent = nullptr);
    ~AnalystWindow();

private slots:
    void loadData();
    void exportReport();

private:
    Ui::AnalystWindow *ui;
    void setupConnections();
    void populateTable(QTableWidget *table, const QVector<QVector<QString>> &data);
    QString generateReport();
};

#endif // ANALYSTWINDOW_H
