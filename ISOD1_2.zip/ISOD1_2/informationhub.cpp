#include "informationhub.h"

InformationHub::InformationHub(QWidget *parent) : QWidget(parent), databaseManager(DatabaseManager::instance())
{
    //qDebug() << "InformationHub constructor called"; // Отладочное сообщение
    setupUI();
    populatePatrolSectors();
    populateDroneSensors();
    populateDronePatrols();
    populateDroneEvents();

    setWindowTitle("Information Hub");
    resize(800, 600); // Устанавливаем размер окна
    //qDebug() << "InformationHub setup complete"; // Отладочное сообщение
}

void InformationHub::setupUI()
{
    //qDebug() << "Setting up UI"; // Отладочное сообщение

    QVBoxLayout *layout = new QVBoxLayout(this);

    // Создание таблицы для секторов патрулирования
    sectorTableWidget = new QTableWidget(this);
    sectorTableWidget->setColumnCount(2);
    sectorTableWidget->setHorizontalHeaderLabels(QStringList() << "ID" << "Name");
    layout->addWidget(sectorTableWidget);

    // Создание таблицы для сенсоров
    droneTableWidget = new QTableWidget(this);
    droneTableWidget->setColumnCount(4);
    droneTableWidget->setHorizontalHeaderLabels(QStringList() << "ID" << "name" << "type" <<"Userid");
    layout->addWidget(droneTableWidget);

    // Создание таблицы для дронов
    eventsTableWidget = new QTableWidget(this);
    eventsTableWidget->setColumnCount(3);
    eventsTableWidget->setHorizontalHeaderLabels(QStringList() << "ID" << "eventtype" << "eventdescription");
    layout->addWidget(eventsTableWidget);

    // Создание таблицы для событий
    eventTableWidget = new QTableWidget(this);
    eventTableWidget->setColumnCount(3);
    eventTableWidget->setHorizontalHeaderLabels(QStringList() << "Event ID" << "Drone ID" << "Event Type");
    layout->addWidget(eventTableWidget);

    setLayout(layout);
    //qDebug() << "UI setup complete"; // Отладочное сообщение
}

void InformationHub::populatePatrolSectors()
{
    // Получение данных о секторах патрулирования из базы данных
    QVector<QVector<QString>> sectorsData = databaseManager.getPatrolSectors();

    // Заполнение таблицы секторов патрулирования
    for (const auto &sector : sectorsData) {
        int row = sectorTableWidget->rowCount();
        sectorTableWidget->insertRow(row);
        for (int i = 0; i < sector.size(); ++i) {
            QTableWidgetItem *item = new QTableWidgetItem(sector[i]);
            sectorTableWidget->setItem(row, i, item);
        }
    }
}

void InformationHub::populateDroneSensors()
{
    // Получение данных о сенсорах из базы данных
    QVector<QVector<QString>> droneData = databaseManager.getDroneData();

    // Заполнение таблицы сенсоров
    for (const auto &drone : droneData) {
        int row = droneTableWidget->rowCount();
        droneTableWidget->insertRow(row);
        for (int i = 0; i < drone.size(); ++i) {
            QTableWidgetItem *item = new QTableWidgetItem(drone[i]);
            droneTableWidget->setItem(row, i, item);
        }
    }
}

void InformationHub::populateDronePatrols()
{
    // Получение данных о патрулировании дронов из базы данных
    QVector<QVector<QString>> eventData = databaseManager.getEventData();

    // Заполнение таблицы патрулирования дронов
    for (const auto &event : eventData) {
        int row = eventsTableWidget->rowCount();
        eventsTableWidget->insertRow(row);
        for (int i = 0; i < event.size(); ++i) {
            QTableWidgetItem *item = new QTableWidgetItem(event[i]);
            eventsTableWidget->setItem(row, i, item);
        }
    }
}

void InformationHub::populateDroneEvents()
{
    // Получение данных о событиях дронов из базы данных
    QVector<QVector<QString>> eventsData = databaseManager.getDroneEvents();

    // Заполнение таблицы событий дронов
    for (const auto &event : eventsData) {
        int row = eventTableWidget->rowCount();
        eventTableWidget->insertRow(row);
        for (int i = 0; i < event.size(); ++i) {
            QTableWidgetItem *item = new QTableWidgetItem(event[i]);
            eventTableWidget->setItem(row, i, item);
        }
    }
}
