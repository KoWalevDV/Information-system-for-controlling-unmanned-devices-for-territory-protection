#ifndef OPERATORWINDOW_H
#define OPERATORWINDOW_H

#include <QWidget>
#include <QLabel>
#include <QImage>
#include <QVideoWidget>
#include <QCamera>
#include <QMediaCaptureSession>
#include <QVBoxLayout>
#include <QTextStream>
#include <QMediaDevices>

class OperatorWindow : public QWidget
{
    Q_OBJECT

public:
    explicit OperatorWindow(QWidget *parent = nullptr);

private:
    QLabel *mapLabel;
    QVideoWidget *videoWidget;
    QCamera *camera;
    QMediaCaptureSession *mediaCaptureSession;

    void setupUI();
    void setupCamera();
    void printVideoDevicesInfo();
};

#endif // OPERATORWINDOW_H
