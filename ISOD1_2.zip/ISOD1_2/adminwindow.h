#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H

#include "databasemanager.h"
#include "login.h"
#include <QMainWindow>
#include <QSqlTableModel>
#include <QMessageBox>//>
#include <QSqlRecord>
#include <QSqlRelationalDelegate>
#include <QCryptographicHash>

namespace Ui {
class AdminWindow;
}

class AdminWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AdminWindow(QWidget *parent = nullptr);
    ~AdminWindow();

private slots:
    void on_addButton_clicked();
    void on_editButton_clicked();
    void on_deleteButton_clicked();
    void on_refreshButton_clicked();
    void on_logoutButton_clicked();

private:
    Ui::AdminWindow *ui;

    QSqlTableModel *usersModel;
    QSqlTableModel *dronesModel;
    QSqlTableModel *sectorsModel;
    QSqlTableModel *sensorsModel;

    void setupModels();
    void setupTableViews();
    bool validateInput(const QString &input);
};

#endif // ADMINWINDOW_H
