#include "userwindow.h"
#include "databasemanager.h"
#include "informationhub.h"
#include <QVBoxLayout>
#include <QApplication>
#include <QDebug>

UserWindow::UserWindow(QWidget *parent) : QWidget(parent), informationHub(nullptr)
{
    QVBoxLayout *layout = new QVBoxLayout(this);

    sectorComboBox = new QComboBox(this);
    sectorComboBox->setPlaceholderText("Выбрать сектор");
    layout->addWidget(sectorComboBox);

    droneComboBox = new QComboBox(this);
    droneComboBox->setPlaceholderText("Выбрать дрона");
    layout->addWidget(droneComboBox);

    eventTypeComboBox = new QComboBox(this);
    eventTypeComboBox->setPlaceholderText("Выбрать тип события");
    layout->addWidget(eventTypeComboBox);

    confirmButton = new QPushButton("Отправить", this);
    layout->addWidget(confirmButton);
    connect(confirmButton, &QPushButton::clicked, this, &UserWindow::confirmData);

    changeModeButton = new QPushButton("Информация", this);
    layout->addWidget(changeModeButton);
    connect(changeModeButton, &QPushButton::clicked, this, &UserWindow::changeMode);

    endSessionButton = new QPushButton("Завершить сеанс", this);
    layout->addWidget(endSessionButton);
    connect(endSessionButton, &QPushButton::clicked, this, &UserWindow::endSession);

    populateSectors();
    populateDrones();
    populateEventTypes();
}

void UserWindow::populateSectors()
{
    QSqlQuery query(DatabaseManager::instance().m_database);
    query.prepare("SELECT Name FROM PatrolSectors");
    if (query.exec()) {
        while (query.next()) {
            sectorComboBox->addItem(query.value(0).toString());
        }
    }
}

void UserWindow::populateDrones()
{
    QSqlQuery query(DatabaseManager::instance().m_database);
    query.prepare("SELECT Name FROM Drones");
    if (query.exec()) {
        while (query.next()) {
            droneComboBox->addItem(query.value(0).toString());
        }
    }
}

void UserWindow::populateEventTypes()
{
    QSqlQuery query(DatabaseManager::instance().m_database);
    query.prepare("SELECT EventType FROM Events");
    if (query.exec()) {
        while (query.next()) {
            eventTypeComboBox->addItem(query.value(0).toString());
        }
    }
}

void UserWindow::confirmData()
{
    QString selectedSector = sectorComboBox->currentText();
    QString selectedDrone = droneComboBox->currentText();
    QString selectedEventType = eventTypeComboBox->currentText();

    QSqlQuery sectorQuery(DatabaseManager::instance().m_database);
    sectorQuery.prepare("SELECT ID FROM PatrolSectors WHERE Name = :name");
    sectorQuery.bindValue(":name", selectedSector);
    sectorQuery.exec();
    sectorQuery.next();
    int sectorId = sectorQuery.value(0).toInt();

    QSqlQuery droneQuery(DatabaseManager::instance().m_database);
    droneQuery.prepare("SELECT ID FROM Drones WHERE Name = :name");
    droneQuery.bindValue(":name", selectedDrone);
    droneQuery.exec();
    droneQuery.next();
    int droneId = droneQuery.value(0).toInt();

    QSqlQuery eventQuery(DatabaseManager::instance().m_database);
    eventQuery.prepare("SELECT ID FROM Events WHERE EventType = :eventType");
    eventQuery.bindValue(":eventType", selectedEventType);
    eventQuery.exec();
    eventQuery.next();
    int eventId = eventQuery.value(0).toInt();

    QSqlQuery insertQuery(DatabaseManager::instance().m_database);
    insertQuery.prepare("INSERT INTO DroneEvent (EventID, DroneID, TimeEvent) VALUES (:eventID, :droneID, :timeEvent)");
    insertQuery.bindValue(":eventID", eventId);
    insertQuery.bindValue(":droneID", droneId);
    insertQuery.bindValue(":timeEvent", QDateTime::currentDateTime());

    if (!insertQuery.exec()) {
        qDebug() << "Failed to insert data into DroneEvent:" << insertQuery.lastError();
    } else {
        qDebug() << "Data inserted successfully into DroneEvent.";

        // Закрываем окно InformationHub, если оно открыто
        if (informationHub && informationHub->isVisible()) {
            informationHub->close();
        }

        // Открываем заново окно InformationHub
        openInformationHub();
    }
}

void UserWindow::changeMode()
{
    qDebug() << "Change mode button clicked";
    openInformationHub();
}

void UserWindow::endSession()
{
    qApp->quit();
}

void UserWindow::openInformationHub()
{
    qDebug() << "Opening InformationHub";
    if (!informationHub) {
        informationHub = new InformationHub(nullptr);
    }
    informationHub->setAttribute(Qt::WA_DeleteOnClose);
    informationHub->setWindowFlag(Qt::Window);
    informationHub->resize(800, 600);
    informationHub->show();
    qDebug() << "InformationHub shown";
}
