#include "login.h"
#include "ui_login.h"
#include "databasemanager.h"
#include "operatorwindow.h"
#include <QMessageBox>
#include "adminwindow.h"
#include "userwindow.h"
#include "analystwindow.h"

Login::Login(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);

    // Подключение сигнала кнопки к слоту
    connect(ui->loginButton, &QPushButton::clicked, this, &Login::handleLoginButtonClicked);
}

Login::~Login()
{
    delete ui;
}

void Login::handleLoginButtonClicked()
{
    QString username = ui->usernameEdit->text();
    QString password = ui->passwordEdit->text();
    QString role = DatabaseManager::instance().authenticateUser(username, password);

    if (!role.isEmpty()) {
        if (role == "Администратор") {
            openAdminWindow();
        } else if (role == "Оператор") {
            openUserWindow();
        } else if (role == "Аналитик") {
            openAnaliystWindow();
        }
        this->close();
    } else {
        QMessageBox::warning(this, "Ошибка авторизации", "Неверное имя пользователя или пароль.");
    }
}

void Login::openUserWindow()
{
    UserWindow *userWindow = new UserWindow();
    userWindow->show();

    // Открытие окна оператора
    OperatorWindow *operatorWindow = new OperatorWindow();
    operatorWindow->show();
}

void Login::openAnaliystWindow()
{
    AnalystWindow *analystWindow = new AnalystWindow();
    analystWindow->show();

}

void Login::openAdminWindow()
{
    AdminWindow *adminWindow = new AdminWindow();
    adminWindow->show();

    // Открытие окна оператора
   // OperatorWindow *operatorWindow = new OperatorWindow();
    //operatorWindow->show();
}
