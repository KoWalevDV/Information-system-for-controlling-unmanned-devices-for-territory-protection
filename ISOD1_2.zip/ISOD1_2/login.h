#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>
#include "ui_login.h"

class Login : public QMainWindow, public Ui::Login
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = nullptr);
    ~Login();

private slots:
    void handleLoginButtonClicked();

private:
    Ui::Login *ui;

    void openUserWindow();
    void openAdminWindow();
    void openAnaliystWindow();
};

#endif // LOGIN_H
