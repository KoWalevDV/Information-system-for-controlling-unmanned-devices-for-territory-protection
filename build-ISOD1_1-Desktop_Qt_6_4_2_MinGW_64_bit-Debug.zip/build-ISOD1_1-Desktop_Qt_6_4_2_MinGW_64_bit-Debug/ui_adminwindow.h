/********************************************************************************
** Form generated from reading UI file 'adminwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINWINDOW_H
#define UI_ADMINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminWindow
{
public:
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *dronesTab;
    QVBoxLayout *verticalLayout_2;
    QTableView *droneTableView;
    QWidget *droneButtonWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *addDroneButton;
    QPushButton *editDroneButton;
    QPushButton *deleteDroneButton;
    QWidget *usersTab;
    QVBoxLayout *verticalLayout_3;
    QTableView *userTableView;
    QWidget *userButtonWidget;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *addUserButton;
    QPushButton *editUserButton;
    QPushButton *deleteUserButton;
    QWidget *sectorsTab;
    QVBoxLayout *verticalLayout_4;
    QTableView *sectorTableView;
    QWidget *sectorButtonWidget;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *addSectorButton;
    QPushButton *editSectorButton;
    QPushButton *deleteSectorButton;
    QWidget *devicesTab;
    QVBoxLayout *verticalLayout_5;
    QTableView *deviceTableView;
    QWidget *deviceButtonWidget;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *addDeviceButton;
    QPushButton *editDeviceButton;
    QPushButton *deleteDeviceButton;

    void setupUi(QWidget *AdminWindow)
    {
        if (AdminWindow->objectName().isEmpty())
            AdminWindow->setObjectName("AdminWindow");
        AdminWindow->resize(800, 600);
        verticalLayout = new QVBoxLayout(AdminWindow);
        verticalLayout->setObjectName("verticalLayout");
        tabWidget = new QTabWidget(AdminWindow);
        tabWidget->setObjectName("tabWidget");
        tabWidget->setMinimumSize(QSize(778, 578));
        tabWidget->setTabPosition(QTabWidget::North);
        dronesTab = new QWidget();
        dronesTab->setObjectName("dronesTab");
        verticalLayout_2 = new QVBoxLayout(dronesTab);
        verticalLayout_2->setObjectName("verticalLayout_2");
        droneTableView = new QTableView(dronesTab);
        droneTableView->setObjectName("droneTableView");
        droneTableView->setMinimumSize(QSize(750, 465));

        verticalLayout_2->addWidget(droneTableView);

        droneButtonWidget = new QWidget(dronesTab);
        droneButtonWidget->setObjectName("droneButtonWidget");
        horizontalLayout = new QHBoxLayout(droneButtonWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        addDroneButton = new QPushButton(droneButtonWidget);
        addDroneButton->setObjectName("addDroneButton");

        horizontalLayout->addWidget(addDroneButton);

        editDroneButton = new QPushButton(droneButtonWidget);
        editDroneButton->setObjectName("editDroneButton");

        horizontalLayout->addWidget(editDroneButton);

        deleteDroneButton = new QPushButton(droneButtonWidget);
        deleteDroneButton->setObjectName("deleteDroneButton");

        horizontalLayout->addWidget(deleteDroneButton);


        verticalLayout_2->addWidget(droneButtonWidget);

        tabWidget->addTab(dronesTab, QString());
        usersTab = new QWidget();
        usersTab->setObjectName("usersTab");
        verticalLayout_3 = new QVBoxLayout(usersTab);
        verticalLayout_3->setObjectName("verticalLayout_3");
        userTableView = new QTableView(usersTab);
        userTableView->setObjectName("userTableView");

        verticalLayout_3->addWidget(userTableView);

        userButtonWidget = new QWidget(usersTab);
        userButtonWidget->setObjectName("userButtonWidget");
        horizontalLayout_2 = new QHBoxLayout(userButtonWidget);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        addUserButton = new QPushButton(userButtonWidget);
        addUserButton->setObjectName("addUserButton");

        horizontalLayout_2->addWidget(addUserButton);

        editUserButton = new QPushButton(userButtonWidget);
        editUserButton->setObjectName("editUserButton");

        horizontalLayout_2->addWidget(editUserButton);

        deleteUserButton = new QPushButton(userButtonWidget);
        deleteUserButton->setObjectName("deleteUserButton");

        horizontalLayout_2->addWidget(deleteUserButton);


        verticalLayout_3->addWidget(userButtonWidget);

        tabWidget->addTab(usersTab, QString());
        sectorsTab = new QWidget();
        sectorsTab->setObjectName("sectorsTab");
        verticalLayout_4 = new QVBoxLayout(sectorsTab);
        verticalLayout_4->setObjectName("verticalLayout_4");
        sectorTableView = new QTableView(sectorsTab);
        sectorTableView->setObjectName("sectorTableView");

        verticalLayout_4->addWidget(sectorTableView);

        sectorButtonWidget = new QWidget(sectorsTab);
        sectorButtonWidget->setObjectName("sectorButtonWidget");
        horizontalLayout_3 = new QHBoxLayout(sectorButtonWidget);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        addSectorButton = new QPushButton(sectorButtonWidget);
        addSectorButton->setObjectName("addSectorButton");

        horizontalLayout_3->addWidget(addSectorButton);

        editSectorButton = new QPushButton(sectorButtonWidget);
        editSectorButton->setObjectName("editSectorButton");

        horizontalLayout_3->addWidget(editSectorButton);

        deleteSectorButton = new QPushButton(sectorButtonWidget);
        deleteSectorButton->setObjectName("deleteSectorButton");

        horizontalLayout_3->addWidget(deleteSectorButton);


        verticalLayout_4->addWidget(sectorButtonWidget);

        tabWidget->addTab(sectorsTab, QString());
        devicesTab = new QWidget();
        devicesTab->setObjectName("devicesTab");
        verticalLayout_5 = new QVBoxLayout(devicesTab);
        verticalLayout_5->setObjectName("verticalLayout_5");
        deviceTableView = new QTableView(devicesTab);
        deviceTableView->setObjectName("deviceTableView");

        verticalLayout_5->addWidget(deviceTableView);

        deviceButtonWidget = new QWidget(devicesTab);
        deviceButtonWidget->setObjectName("deviceButtonWidget");
        horizontalLayout_4 = new QHBoxLayout(deviceButtonWidget);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        addDeviceButton = new QPushButton(deviceButtonWidget);
        addDeviceButton->setObjectName("addDeviceButton");

        horizontalLayout_4->addWidget(addDeviceButton);

        editDeviceButton = new QPushButton(deviceButtonWidget);
        editDeviceButton->setObjectName("editDeviceButton");

        horizontalLayout_4->addWidget(editDeviceButton);

        deleteDeviceButton = new QPushButton(deviceButtonWidget);
        deleteDeviceButton->setObjectName("deleteDeviceButton");

        horizontalLayout_4->addWidget(deleteDeviceButton);


        verticalLayout_5->addWidget(deviceButtonWidget);

        tabWidget->addTab(devicesTab, QString());

        verticalLayout->addWidget(tabWidget);


        retranslateUi(AdminWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(AdminWindow);
    } // setupUi

    void retranslateUi(QWidget *AdminWindow)
    {
        AdminWindow->setWindowTitle(QCoreApplication::translate("AdminWindow", "Admin Window", nullptr));
        addDroneButton->setText(QCoreApplication::translate("AdminWindow", "Add Drone", nullptr));
        editDroneButton->setText(QCoreApplication::translate("AdminWindow", "Edit Drone", nullptr));
        deleteDroneButton->setText(QCoreApplication::translate("AdminWindow", "Delete Drone", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(dronesTab), QCoreApplication::translate("AdminWindow", "Drones", nullptr));
        addUserButton->setText(QCoreApplication::translate("AdminWindow", "Add User", nullptr));
        editUserButton->setText(QCoreApplication::translate("AdminWindow", "Edit User", nullptr));
        deleteUserButton->setText(QCoreApplication::translate("AdminWindow", "Delete User", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(usersTab), QCoreApplication::translate("AdminWindow", "Users", nullptr));
        addSectorButton->setText(QCoreApplication::translate("AdminWindow", "Add Sector", nullptr));
        editSectorButton->setText(QCoreApplication::translate("AdminWindow", "Edit Sector", nullptr));
        deleteSectorButton->setText(QCoreApplication::translate("AdminWindow", "Delete Sector", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(sectorsTab), QCoreApplication::translate("AdminWindow", "Sectors", nullptr));
        addDeviceButton->setText(QCoreApplication::translate("AdminWindow", "Add Device", nullptr));
        editDeviceButton->setText(QCoreApplication::translate("AdminWindow", "Edit Device", nullptr));
        deleteDeviceButton->setText(QCoreApplication::translate("AdminWindow", "Delete Device", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(devicesTab), QCoreApplication::translate("AdminWindow", "Devices", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdminWindow: public Ui_AdminWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINWINDOW_H
