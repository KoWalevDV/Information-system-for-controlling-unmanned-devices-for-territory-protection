/****************************************************************************
** Meta object code from reading C++ file 'adminwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ISOD1_1/adminwindow.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'adminwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_AdminWindow_t {
    uint offsetsAndSizes[30];
    char stringdata0[12];
    char stringdata1[26];
    char stringdata2[1];
    char stringdata3[27];
    char stringdata4[29];
    char stringdata5[25];
    char stringdata6[26];
    char stringdata7[28];
    char stringdata8[27];
    char stringdata9[28];
    char stringdata10[30];
    char stringdata11[27];
    char stringdata12[28];
    char stringdata13[30];
    char stringdata14[19];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_AdminWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_AdminWindow_t qt_meta_stringdata_AdminWindow = {
    {
        QT_MOC_LITERAL(0, 11),  // "AdminWindow"
        QT_MOC_LITERAL(12, 25),  // "on_addDroneButton_clicked"
        QT_MOC_LITERAL(38, 0),  // ""
        QT_MOC_LITERAL(39, 26),  // "on_editDroneButton_clicked"
        QT_MOC_LITERAL(66, 28),  // "on_deleteDroneButton_clicked"
        QT_MOC_LITERAL(95, 24),  // "on_addUserButton_clicked"
        QT_MOC_LITERAL(120, 25),  // "on_editUserButton_clicked"
        QT_MOC_LITERAL(146, 27),  // "on_deleteUserButton_clicked"
        QT_MOC_LITERAL(174, 26),  // "on_addSectorButton_clicked"
        QT_MOC_LITERAL(201, 27),  // "on_editSectorButton_clicked"
        QT_MOC_LITERAL(229, 29),  // "on_deleteSectorButton_clicked"
        QT_MOC_LITERAL(259, 26),  // "on_addDeviceButton_clicked"
        QT_MOC_LITERAL(286, 27),  // "on_editDeviceButton_clicked"
        QT_MOC_LITERAL(314, 29),  // "on_deleteDeviceButton_clicked"
        QT_MOC_LITERAL(344, 18)   // "openOperatorWindow"
    },
    "AdminWindow",
    "on_addDroneButton_clicked",
    "",
    "on_editDroneButton_clicked",
    "on_deleteDroneButton_clicked",
    "on_addUserButton_clicked",
    "on_editUserButton_clicked",
    "on_deleteUserButton_clicked",
    "on_addSectorButton_clicked",
    "on_editSectorButton_clicked",
    "on_deleteSectorButton_clicked",
    "on_addDeviceButton_clicked",
    "on_editDeviceButton_clicked",
    "on_deleteDeviceButton_clicked",
    "openOperatorWindow"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_AdminWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   92,    2, 0x08,    1 /* Private */,
       3,    0,   93,    2, 0x08,    2 /* Private */,
       4,    0,   94,    2, 0x08,    3 /* Private */,
       5,    0,   95,    2, 0x08,    4 /* Private */,
       6,    0,   96,    2, 0x08,    5 /* Private */,
       7,    0,   97,    2, 0x08,    6 /* Private */,
       8,    0,   98,    2, 0x08,    7 /* Private */,
       9,    0,   99,    2, 0x08,    8 /* Private */,
      10,    0,  100,    2, 0x08,    9 /* Private */,
      11,    0,  101,    2, 0x08,   10 /* Private */,
      12,    0,  102,    2, 0x08,   11 /* Private */,
      13,    0,  103,    2, 0x08,   12 /* Private */,
      14,    0,  104,    2, 0x08,   13 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject AdminWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_AdminWindow.offsetsAndSizes,
    qt_meta_data_AdminWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_AdminWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<AdminWindow, std::true_type>,
        // method 'on_addDroneButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_editDroneButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_deleteDroneButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addUserButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_editUserButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_deleteUserButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addSectorButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_editSectorButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_deleteSectorButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addDeviceButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_editDeviceButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_deleteDeviceButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openOperatorWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void AdminWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<AdminWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_addDroneButton_clicked(); break;
        case 1: _t->on_editDroneButton_clicked(); break;
        case 2: _t->on_deleteDroneButton_clicked(); break;
        case 3: _t->on_addUserButton_clicked(); break;
        case 4: _t->on_editUserButton_clicked(); break;
        case 5: _t->on_deleteUserButton_clicked(); break;
        case 6: _t->on_addSectorButton_clicked(); break;
        case 7: _t->on_editSectorButton_clicked(); break;
        case 8: _t->on_deleteSectorButton_clicked(); break;
        case 9: _t->on_addDeviceButton_clicked(); break;
        case 10: _t->on_editDeviceButton_clicked(); break;
        case 11: _t->on_deleteDeviceButton_clicked(); break;
        case 12: _t->openOperatorWindow(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *AdminWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AdminWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_AdminWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int AdminWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 13;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
