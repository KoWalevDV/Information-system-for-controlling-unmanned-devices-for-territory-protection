/********************************************************************************
** Form generated from reading UI file 'operatorwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OPERATORWINDOW_H
#define UI_OPERATORWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <qcameraviewfinder.h>

QT_BEGIN_NAMESPACE

class Ui_OperatorWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QCameraViewfinder *viewfinder;
    QLabel *mapLabel;

    void setupUi(QMainWindow *OperatorWindow)
    {
        if (OperatorWindow->objectName().isEmpty())
            OperatorWindow->setObjectName("OperatorWindow");
        OperatorWindow->resize(800, 600);
        centralwidget = new QWidget(OperatorWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName("verticalLayout");
        viewfinder = new QCameraViewfinder(centralwidget);
        viewfinder->setObjectName("viewfinder");

        verticalLayout->addWidget(viewfinder);

        mapLabel = new QLabel(centralwidget);
        mapLabel->setObjectName("mapLabel");

        verticalLayout->addWidget(mapLabel);

        OperatorWindow->setCentralWidget(centralwidget);

        retranslateUi(OperatorWindow);

        QMetaObject::connectSlotsByName(OperatorWindow);
    } // setupUi

    void retranslateUi(QMainWindow *OperatorWindow)
    {
        OperatorWindow->setWindowTitle(QCoreApplication::translate("OperatorWindow", "Operator Window", nullptr));
        mapLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class OperatorWindow: public Ui_OperatorWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OPERATORWINDOW_H
